$(document).ready(function () {
    // Function to show a custom message box
    function showMessageBox(message, type = 'success') {
        const messageBox = $('#messageBox');
        messageBox.removeClass('success error').addClass(type).text(message).fadeIn().delay(3000).fadeOut();
    }

    // Function to load tasks based on filter
    function loadTasks(filter) {
        $('#loadingTasksError').hide();
        $.ajax({
            url: 'index.php',
            type: 'POST',
            data: { action: 'getTasks', filter: filter },
            success: function (response) {
                if (response.success) {
                    const taskList = $('#taskList');
                    taskList.empty();
                    if (response.tasks.length === 0) {
                        taskList.append('<p class="no-tasks-message">No tasks found for this filter. Add a new task!</p>');
                    } else {
                        response.tasks.forEach(task => {
                            const taskStatusClass = task.status.toLowerCase();
                            const taskPriorityClass = task.priority.toLowerCase();
                            const completeButton = task.status === 'Pending' ?
                                `<button class="action-btn complete-btn" title="Mark as Complete"><i class="fas fa-check-circle"></i></button>` :
                                `<button class="action-btn uncomplete-btn" title="Mark as Pending"><i class="fas fa-undo"></i></button>`;

                            taskList.append(`
                                        <div class="task-item ${taskStatusClass} ${taskPriorityClass}" data-id="${task.id}">
                                            <div class="task-info">
                                                <h3>${task.subject}</h3>
                                                <p class="description">${task.description || ''}</p>
                                                <p class="due-date">Due: ${new Date(task.due_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</p>
                                                <span class="task-priority priority-${taskPriorityClass}">${task.priority}</span>
                                            </div>
                                            <div class="task-actions">
                                                ${completeButton}
                                                <button class="action-btn delete-btn" title="Delete Task"><i class="fas fa-trash-alt"></i></button>
                                            </div>
                                        </div>
                                    `);
                        });
                    }
                } else {
                    $('#loadingTasksError').text(response.message || 'Error loading tasks.').show();
                }
            },
            error: function () {
                $('#loadingTasksError').text('An error occurred while fetching tasks.').show();
            }
        });
    }

    // Function to update study progress stats
    function updateStudyProgress() {
        $.ajax({
            url: 'index.php',
            type: 'POST',
            data: { action: 'getStudyProgress' },
            success: function (response) {
                if (response.success) {
                    $('#totalTasksCount').text(response.total);
                    $('#completedTasksCount').text(response.completed);
                    $('#totalTasksStat').text(response.total);
                    $('#completedTasksStat').text(response.completed);
                    $('#pendingTasksStat').text(response.pending);
                    $('#overdueTasksStat').text(response.overdue);

                    const progressPercentage = response.total > 0 ? (response.completed / response.total) * 100 : 0;
                    $('.progress-bar').css('width', progressPercentage + '%');
                }
            }
        });
    }

    // Set today's date as min for due date input
    const today = new Date().toISOString().split('T')[0];
    $('#dueDate').attr('min', today);

    // Add Task Form submission
    $('#addTaskForm').submit(function (e) {
        e.preventDefault();
        $.ajax({
            url: 'index.php',
            type: 'POST',
            data: $(this).serialize() + '&action=addTask',
            success: function (response) {
                if (response.success) {
                    showMessageBox(response.message, 'success');
                    $('#addTaskForm')[0].reset(); // Clear the form
                    $('#dueDate').attr('min', today); // Reset min date
                    loadTasks($('.filter-btn.active').data('filter')); // Reload tasks with current filter
                    updateStudyProgress(); // Update progress stats
                } else {
                    showMessageBox(response.message, 'error');
                }
            },
            error: function () {
                showMessageBox('An error occurred while adding the task.', 'error');
            }
        });
    });

    // Filter buttons click handler
    $('.filter-buttons button').click(function () {
        $('.filter-buttons button').removeClass('active');
        $(this).addClass('active');
        const filter = $(this).data('filter');
        loadTasks(filter);
    });

    // Mark as Complete/Pending handler (delegated event)
    $(document).on('click', '.complete-btn, .uncomplete-btn', function () {
        const taskId = $(this).closest('.task-item').data('id');
        const newStatus = $(this).hasClass('complete-btn') ? 'Completed' : 'Pending';
        const button = $(this);

        $.ajax({
            url: 'index.php',
            type: 'POST',
            data: { action: 'updateTaskStatus', taskId: taskId, status: newStatus },
            success: function (response) {
                if (response.success) {
                    showMessageBox(response.message, 'success');
                    loadTasks($('.filter-btn.active').data('filter')); // Reload tasks
                    updateStudyProgress(); // Update progress stats
                } else {
                    showMessageBox(response.message, 'error');
                }
            },
            error: function () {
                showMessageBox('An error occurred while updating task status.', 'error');
            }
        });
    });

    // Delete Task handler (delegated event)
    $(document).on('click', '.delete-btn', function () {
        const taskId = $(this).closest('.task-item').data('id');
        // You could add a custom confirmation dialog here instead of `confirm()`
        if (confirm('Are you sure you want to delete this task?')) {
            $.ajax({
                url: 'index.php',
                type: 'POST',
                data: { action: 'deleteTask', taskId: taskId },
                success: function (response) {
                    if (response.success) {
                        showMessageBox(response.message, 'success');
                        loadTasks($('.filter-btn.active').data('filter')); // Reload tasks
                        updateStudyProgress(); // Update progress stats
                    } else {
                        showMessageBox(response.message, 'error');
                    }
                },
                error: function () {
                    showMessageBox('An error occurred while deleting the task.', 'error');
                }
            });
        }
    });

    // Hamburger menu toggle functionality
    $('.hamburger-menu').click(function () {
        $('.navbar-nav').toggleClass('open');
    });

    // Initial load of tasks and progress
    loadTasks($('.filter-btn.active').data('filter'));
    updateStudyProgress();
});
