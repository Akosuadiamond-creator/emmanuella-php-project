<?php
require_once 'db_connection.php';

// Function to fetch tasks based on filter
function getTasks($conn, $filter = 'All') {
    $sql = "SELECT * FROM tasks";
    $params = [];
    $types = '';

    // Apply filters
    switch ($filter) {
        case 'Pending':
            $sql .= " WHERE status = 'Pending'";
            break;
        case 'Completed':
            $sql .= " WHERE status = 'Completed'";
            break;
        case 'Today':
            $sql .= " WHERE due_date = CURDATE() AND status = 'Pending'";
            break;
        case 'This Week':
            $sql .= " WHERE YEARWEEK(due_date, 1) = YEARWEEK(CURDATE(), 1) AND status = 'Pending'";
            break;
        case 'This Month':
            $sql .= " WHERE MONTH(due_date) = MONTH(CURDATE()) AND YEAR(due_date) = YEAR(CURDATE()) AND status = 'Pending'";
            break;
        case 'All':
        default:
            // No additional WHERE clause for 'All'
            break;
    }
    $sql .= " ORDER BY due_date ASC, priority DESC"; // Order by due date and then priority

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        error_log("Prepare failed: " . $conn->error);
        return [];
    }

    // Bind parameters if any
    if ($types) {
        $stmt->bind_param($types, ...$params);
    }

    $stmt->execute();
    $result = $stmt->get_result();
    $tasks = [];
    while ($row = $result->fetch_assoc()) {
        $tasks[] = $row;
    }
    $stmt->close();
    return $tasks;
}

// Handle AJAX requests
if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
    $action = $_POST['action'] ?? '';

    header('Content-Type: application/json');

    switch ($action) {
        case 'addTask':
            $subject = $_POST['subject'] ?? '';
            $description = $_POST['description'] ?? '';
            $dueDate = $_POST['dueDate'] ?? '';
            $priority = $_POST['priority'] ?? 'Low';

            if (empty($subject) || empty($dueDate)) {
                echo json_encode(['success' => false, 'message' => 'Subject and Due Date are required.']);
                exit();
            }

            $sql = "INSERT INTO tasks (subject, description, due_date, priority) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("ssss", $subject, $description, $dueDate, $priority);
                if ($stmt->execute()) {
                    echo json_encode(['success' => true, 'message' => 'Task added successfully.']);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Failed to add task: ' . $stmt->error]);
                }
                $stmt->close();
            } else {
                echo json_encode(['success' => false, 'message' => 'Prepare statement failed: ' . $conn->error]);
            }
            break;

        case 'updateTaskStatus':
            $taskId = $_POST['taskId'] ?? 0;
            $status = $_POST['status'] ?? ''; // 'Completed' or 'Pending'

            if ($taskId > 0 && ($status == 'Completed' || $status == 'Pending')) {
                $sql = "UPDATE tasks SET status = ? WHERE id = ?";
                $stmt = $conn->prepare($sql);
                if ($stmt) {
                    $stmt->bind_param("si", $status, $taskId);
                    if ($stmt->execute()) {
                        echo json_encode(['success' => true, 'message' => 'Task status updated.']);
                    } else {
                        echo json_encode(['success' => false, 'message' => 'Failed to update status: ' . $stmt->error]);
                    }
                    $stmt->close();
                } else {
                    echo json_encode(['success' => false, 'message' => 'Prepare statement failed: ' . $conn->error]);
                }
            } else {
                echo json_encode(['success' => false, 'message' => 'Invalid task ID or status.']);
            }
            break;

        case 'deleteTask':
            $taskId = $_POST['taskId'] ?? 0;

            if ($taskId > 0) {
                $sql = "DELETE FROM tasks WHERE id = ?";
                $stmt = $conn->prepare($sql);
                if ($stmt) {
                    $stmt->bind_param("i", $taskId);
                    if ($stmt->execute()) {
                        echo json_encode(['success' => true, 'message' => 'Task deleted.']);
                    } else {
                        echo json_encode(['success' => false, 'message' => 'Failed to delete task: ' . $stmt->error]);
                    }
                    $stmt->close();
                } else {
                    echo json_encode(['success' => false, 'message' => 'Prepare statement failed: ' . $conn->error]);
                }
            } else {
                echo json_encode(['success' => false, 'message' => 'Invalid task ID.']);
            }
            break;

        case 'getTasks':
            $filter = $_POST['filter'] ?? 'All';
            $tasks = getTasks($conn, $filter);
            echo json_encode(['success' => true, 'tasks' => $tasks]);
            break;

        case 'getStudyProgress':
            $totalTasksResult = $conn->query("SELECT COUNT(*) AS total FROM tasks");
            $completedTasksResult = $conn->query("SELECT COUNT(*) AS completed FROM tasks WHERE status = 'Completed'");
            $pendingTasksResult = $conn->query("SELECT COUNT(*) AS pending FROM tasks WHERE status = 'Pending'");
            $overdueTasksResult = $conn->query("SELECT COUNT(*) AS overdue FROM tasks WHERE due_date < CURDATE() AND status = 'Pending'");

            $total = $totalTasksResult->fetch_assoc()['total'];
            $completed = $completedTasksResult->fetch_assoc()['completed'];
            $pending = $pendingTasksResult->fetch_assoc()['pending'];
            $overdue = $overdueTasksResult->fetch_assoc()['overdue'];

            echo json_encode([
                'success' => true,
                'total' => $total,
                'completed' => $completed,
                'pending' => $pending,
                'overdue' => $overdue
            ]);
            break;

        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action.']);
            break;
    }
    $conn->close();
    exit(); // Important to exit after AJAX response
}

// Initial load for the page
$currentFilter = $_GET['filter'] ?? 'All';
$tasks = getTasks($conn, $currentFilter);

// Get study progress stats for initial load
$totalTasksResult = $conn->query("SELECT COUNT(*) AS total FROM tasks");
$completedTasksResult = $conn->query("SELECT COUNT(*) AS completed FROM tasks WHERE status = 'Completed'");
$pendingTasksResult = $conn->query("SELECT COUNT(*) AS pending FROM tasks WHERE status = 'Pending'");
$overdueTasksResult = $conn->query("SELECT COUNT(*) AS overdue FROM tasks WHERE due_date < CURDATE() AND status = 'Pending'");

$total_tasks = $totalTasksResult->fetch_assoc()['total'];
$completed_tasks = $completedTasksResult->fetch_assoc()['completed'];
$pending_tasks = $pendingTasksResult->fetch_assoc()['pending'];
$overdue_tasks = $overdueTasksResult->fetch_assoc()['overdue'];

$conn->close();
?>