-- Create the database if it doesn't exist
CREATE DATABASE IF NOT EXISTS student_study_planner;

-- Use the newly created database
USE student_study_planner;

-- Create the tasks table
CREATE TABLE IF NOT EXISTS tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    subject VARCHAR(255) NOT NULL,
    description TEXT,
    due_date DATE NOT NULL,
    priority ENUM('Low', 'Medium', 'High') DEFAULT 'Low',
    status ENUM('Pending', 'Completed') DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Optional: Insert some sample data
INSERT INTO tasks (subject, description, due_date, priority, status) VALUES
('Advanced Web Engineering', 'Introduction to php.', '2025-08-30', 'High', 'Pending'),
('Research Methods For Scientists', 'Summarize some research papers.', '2025-09-01', 'Medium', 'Pending'),
('Mobile App Development', 'Learn about flutter basics.', '2025-08-29', 'Low', 'Completed');

