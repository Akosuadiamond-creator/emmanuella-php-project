<?php
require_once 'db_connection.php';
require_once 'functions.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Study Planner</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <header class="navbar">
        <div class="navbar-brand">
            <i class="fas fa-book-reader"></i> Study Planner
        </div>
        <button class="hamburger-menu" aria-label="Toggle navigation">
            <i class="fas fa-bars"></i>
        </button>
        <nav class="navbar-nav">
            <a href="?filter=All" class="<?= $currentFilter == 'All' ? 'active' : '' ?>">Dashboard</a>
            <a href="?filter=Today" class="<?= $currentFilter == 'Today' ? 'active' : '' ?>">Today</a>
            <a href="?filter=This Week" class="<?= $currentFilter == 'This Week' ? 'active' : '' ?>">This Week</a>
            <a href="?filter=This Month" class="<?= $currentFilter == 'This Month' ? 'active' : '' ?>">This Month</a>
        </nav>
    </header>

    <main class="container">
        <div class="card add-task-card">
            <h2>Add New Task</h2>
            <form id="addTaskForm">
                <div class="form-group">
                    <label for="subject">Subject</label>
                    <input type="text" id="subject" name="subject" placeholder="e.g. Mathematics" required>
                </div>
                <div class="form-group">
                    <label for="description">Task Description</label>
                    <textarea id="description" name="description" placeholder="Describe the study task..."></textarea>
                </div>
                <div class="form-group">
                    <label for="dueDate">Due Date</label>
                    <input type="date" id="dueDate" name="dueDate" required>
                </div>
                <div class="form-group">
                    <label>Priority</label>
                    <div class="priority-options">
                        <label>
                            <input type="radio" name="priority" value="Low" checked>
                            <span class="priority-low">Low</span>
                        </label>
                        <label>
                            <input type="radio" name="priority" value="Medium">
                            <span class="priority-medium">Medium</span>
                        </label>
                        <label>
                            <input type="radio" name="priority" value="High">
                            <span class="priority-high">High</span>
                        </label>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-plus-circle"></i> Add To Planner</button>
                <div id="messageBox" class="message-box" style="display: none;"></div>
            </form>
        </div>

        <div class="tasks-section">
            <div class="card your-tasks-card">
                <h2>Your Study Tasks</h2>
                <div class="filter-buttons">
                    <button class="filter-btn active" data-filter="All">All Tasks</button>
                    <button class="filter-btn" data-filter="Pending">Pending</button>
                    <button class="filter-btn" data-filter="Completed">Completed</button>
                    <button class="filter-btn" data-filter="Today">Today</button>
                    <button class="filter-btn" data-filter="This Week">This Week</button>
                    <button class="filter-btn" data-filter="This Month">This Month</button>
                </div>
                <div id="taskList" class="task-list">
                    <?php if (empty($tasks)): ?>
                        <p class="no-tasks-message">No tasks found for this filter. Add a new task!</p>
                    <?php else: ?>
                        <?php foreach ($tasks as $task): ?>
                            <div class="task-item <?= strtolower($task['status']) ?> <?= strtolower($task['priority']) ?>" data-id="<?= $task['id'] ?>">
                                <div class="task-info">
                                    <h3><?= htmlspecialchars($task['subject']) ?></h3>
                                    <p class="description"><?= htmlspecialchars($task['description']) ?></p>
                                    <p class="due-date">Due: <?= date('M d, Y', strtotime($task['due_date'])) ?></p>
                                    <span class="task-priority priority-<?= strtolower($task['priority']) ?>"><?= $task['priority'] ?></span>
                                </div>
                                <div class="task-actions">
                                    <?php if ($task['status'] === 'Pending'): ?>
                                        <button class="action-btn complete-btn" title="Mark as Complete"><i class="fas fa-check-circle"></i></button>
                                    <?php else: ?>
                                        <button class="action-btn uncomplete-btn" title="Mark as Pending"><i class="fas fa-undo"></i></button>
                                    <?php endif; ?>
                                    <button class="action-btn delete-btn" title="Delete Task"><i class="fas fa-trash-alt"></i></button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <div id="loadingTasksError" class="error-message" style="display: none;">Error loading tasks</div>
            </div>

            <div class="card study-progress-card">
                <h2>Study Progress</h2>
                <p class="progress-summary">You've completed <span id="completedTasksCount"><?= $completed_tasks ?></span> out of <span id="totalTasksCount"><?= $total_tasks ?></span> tasks</p>
                <div class="progress-bar-container">
                    <div class="progress-bar" style="width: <?= $total_tasks > 0 ? ($completed_tasks / $total_tasks) * 100 : 0 ?>%;"></div>
                </div>
                <div class="progress-stats">
                    <div class="stat-item">
                        <span id="totalTasksStat"><?= $total_tasks ?></span>
                        <p>Total Tasks</p>
                    </div>
                    <div class="stat-item">
                        <span id="completedTasksStat"><?= $completed_tasks ?></span>
                        <p>Completed</p>
                    </div>
                    <div class="stat-item">
                        <span id="pendingTasksStat"><?= $pending_tasks ?></span>
                        <p>Pending</p>
                    </div>
                    <div class="stat-item">
                        <span id="overdueTasksStat"><?= $overdue_tasks ?></span>
                        <p>Overdue</p>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="script.js"></script>

</body>

</html>